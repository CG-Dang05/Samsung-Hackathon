#!/usr/bin/env python3
"""
Setup script for Untethered AI Companion Backend
Automates the installation and setup process
"""

import os
import sys
import subprocess
import platform
from pathlib import Path

def run_command(command, description):
    """Run a command and handle errors"""
    print(f"🔄 {description}...")
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print(f"✅ {description} completed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ {description} failed: {e}")
        print(f"Error output: {e.stderr}")
        return False

def check_python_version():
    """Check if Python version is compatible"""
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 8):
        print("❌ Python 3.8+ is required")
        print(f"Current version: {version.major}.{version.minor}.{version.micro}")
        return False
    print(f"✅ Python version {version.major}.{version.minor}.{version.micro} is compatible")
    return True

def create_virtual_environment():
    """Create virtual environment"""
    venv_path = Path(".venv")
    if venv_path.exists():
        print("✅ Virtual environment already exists")
        return True
    
    return run_command("python -m venv .venv", "Creating virtual environment")

def activate_virtual_environment():
    """Activate virtual environment"""
    if platform.system() == "Windows":
        activate_script = ".venv\\Scripts\\activate"
    else:
        activate_script = "source .venv/bin/activate"
    
    print(f"📝 To activate virtual environment, run: {activate_script}")
    return True

def install_dependencies():
    """Install Python dependencies"""
    if platform.system() == "Windows":
        pip_cmd = ".venv\\Scripts\\pip"
    else:
        pip_cmd = ".venv/bin/pip"
    
    return run_command(f"{pip_cmd} install -r requirements.txt", "Installing dependencies")

def create_env_file():
    """Create .env file if it doesn't exist"""
    env_file = Path(".env")
    if env_file.exists():
        print("✅ .env file already exists")
        return True
    
    env_content = """# Untethered AI Companion Backend Configuration

# Google Gemini API Key (optional - system works without it)
# Get your key from: https://makersuite.google.com/app/apikey
GOOGLE_API_KEY=your_gemini_api_key_here

# OpenAI API Key (optional - fallback)
# Get your key from: https://platform.openai.com/api-keys
OPENAI_API_KEY=your_openai_api_key_here

# Note: If no API keys are provided, the system will work in offline mode
# with intelligent fallback responses.
"""
    
    try:
        with open(env_file, 'w') as f:
            f.write(env_content)
        print("✅ Created .env file")
        print("📝 Please edit .env file with your API keys (optional)")
        return True
    except Exception as e:
        print(f"❌ Failed to create .env file: {e}")
        return False

def create_run_script():
    """Create run script for easy startup"""
    if platform.system() == "Windows":
        script_content = """@echo off
echo Starting Untethered AI Companion Backend...
echo.
echo Activating virtual environment...
call .venv\\Scripts\\activate
echo.
echo Starting server...
uvicorn main:app --reload --host 0.0.0.0 --port 8000
pause
"""
        script_file = "run.bat"
    else:
        script_content = """#!/bin/bash
echo "Starting Untethered AI Companion Backend..."
echo ""
echo "Activating virtual environment..."
source .venv/bin/activate
echo ""
echo "Starting server..."
uvicorn main:app --reload --host 0.0.0.0 --port 8000
"""
        script_file = "run.sh"
    
    try:
        with open(script_file, 'w') as f:
            f.write(script_content)
        
        if platform.system() != "Windows":
            os.chmod(script_file, 0o755)
        
        print(f"✅ Created {script_file} for easy startup")
        return True
    except Exception as e:
        print(f"❌ Failed to create run script: {e}")
        return False

def main():
    """Main setup function"""
    print("🚀 Untethered AI Companion Backend Setup")
    print("=" * 50)
    
    # Check Python version
    if not check_python_version():
        sys.exit(1)
    
    # Create virtual environment
    if not create_virtual_environment():
        sys.exit(1)
    
    # Install dependencies
    if not install_dependencies():
        sys.exit(1)
    
    # Create .env file
    create_env_file()
    
    # Create run script
    create_run_script()
    
    print("\n" + "=" * 50)
    print("🎉 Setup completed successfully!")
    print("\n📋 Next steps:")
    print("1. Edit .env file with your API keys (optional)")
    print("2. Activate virtual environment:")
    if platform.system() == "Windows":
        print("   .venv\\Scripts\\activate")
    else:
        print("   source .venv/bin/activate")
    print("3. Start the backend:")
    print("   uvicorn main:app --reload --host 0.0.0.0 --port 8000")
    print("   OR use the run script:")
    if platform.system() == "Windows":
        print("   run.bat")
    else:
        print("   ./run.sh")
    print("\n🌐 Access points:")
    print("   - Web Interface: http://localhost:8000")
    print("   - API Docs: http://localhost:8000/docs")
    print("   - Health Check: http://localhost:8000/health")
    print("\n📚 For more information, see README.md")

if __name__ == "__main__":
    main()
