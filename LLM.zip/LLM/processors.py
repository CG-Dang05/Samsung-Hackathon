import logging
from datetime import datetime
from typing import Dict, Any
from fastapi import WebSocket

from memory import Message, conversation_memory, visual_memory, semantic_memory, cache
from llm import smart_llm
from config import FEATURES
from asyncio import Queue

logger = logging.getLogger(__name__)

async def process_chat_message(text: str) -> str:
    """Process chat messages with context"""
    try:
        # Create message
        msg = Message(content=text, type="text")
        
        # Add to conversation memory
        conversation_memory.add(msg)
        
        # Add to semantic memory for long-term recall
        semantic_memory.add(msg)
        
        # Get relevant context
        conv_context = conversation_memory.search(msg, limit=3)
        sem_context = semantic_memory.search(msg, limit=2)
        
        # Build context string
        context = "\n".join([
            "Previous conversation:",
            *[f"{m.content}" for m in conv_context],
            "\nRelevant memories:",
            *[f"{m.content}" for m in sem_context]
        ])
        
        # Generate response using LLM
        response = smart_llm(f"Context:\n{context}\n\nUser: {text}")
        
        # Cache response
        cache.set(f"chat_{datetime.now().timestamp()}", {
            "input": text,
            "context": context,
            "response": response
        })
        
        return response
        
    except Exception as e:
        logger.error(f"Error processing chat: {e}")
        return "I'm having trouble processing that right now. Please try again."

async def process_vision_message(image_data: bytes) -> str:
    """Process vision inputs"""
    try:
        # Create message
        msg = Message(content=image_data, type="image")
        
        # Process image
        visual_memory.add(msg)
        
        # Get similar images
        similar = visual_memory.search(msg, limit=3)
        
        # Build context
        context = []
        if similar:
            context.append("I've seen similar images before:")
            for m in similar:
                if m.metadata.get("description"):
                    context.append(f"- {m.metadata['description']}")
        
        # Generate description
        response = smart_llm(
            "Describe what you see in this image." +
            ("\n\nContext:\n" + "\n".join(context) if context else "")
        )
        
        # Update message metadata
        msg.metadata["description"] = response
        
        # Cache result
        cache.set(f"vision_{datetime.now().timestamp()}", {
            "description": response,
            "similar_count": len(similar)
        })
        
        return response
        
    except Exception as e:
        logger.error(f"Error processing vision input: {e}")
        return "I'm having trouble processing that image. Please try again."

# Assume task_queue is defined elsewhere and imported if needed
# Remove unused imports and variables

async def process_background_tasks(task_queue: Queue):
    """Background task processor"""
    while True:
        try:
            task = await task_queue.get()
            
            if task.get("type") == "memory_optimization":
                # Optimize memories
                conversation_memory.optimize()
                visual_memory.optimize()
                semantic_memory.optimize()
                
            elif task.get("type") == "cache_cleanup":
                # Clean old cache entries
                cache.clear()
                
            elif task.get("type") == "cloud_sync" and FEATURES.get("cloud_sync"):
                # Sync with cloud when available
                await sync_with_cloud()
                
        except Exception as e:
            logger.error(f"Error in background task: {e}")
        finally:
            task_queue.task_done()

async def sync_with_cloud():
    """Sync memory and cache with cloud storage"""
    try:
        # TODO: Implement cloud sync logic
        pass
    except Exception as e:
        logger.error(f"Cloud sync failed: {e}")

def get_system_stats() -> dict:
    """Get current system statistics"""
    return {
        "memory": {
            "conversation": conversation_memory.get_stats(),
            "visual": visual_memory.get_stats(),
            "semantic": semantic_memory.get_stats()
        },
        "cache": cache.get_stats(),
        "features": FEATURES,
        "api_status": {
            "llm": "openai" in globals(),
            "cloud_sync": FEATURES.get("cloud_sync", False)
        }
    }
