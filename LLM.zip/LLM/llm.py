import os
import google.generativeai as genai
from openai import OpenAI
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

GEMINI_MODEL = "gemini-1.5-flash"
_openai_client = None

def init_llms():
    """Initialize LLM clients with proper error handling"""
    global _openai_client
    
    # Initialize Gemini
    google_key = os.getenv("GOOGLE_API_KEY")
    if google_key:
        try:
            genai.configure(api_key=google_key)
            logger.info("Gemini API configured successfully")
        except Exception as e:
            logger.warning(f"Failed to configure Gemini: {e}")
    
    # Initialize OpenAI
    openai_key = os.getenv("OPENAI_API_KEY")
    if openai_key:
        try:
            _openai_client = OpenAI(api_key=openai_key)
            logger.info("OpenAI API configured successfully")
        except Exception as e:
            logger.warning(f"Failed to configure OpenAI: {e}")
    
    return _openai_client

def call_gemini(prompt: str) -> str:
    """Call Gemini API with error handling"""
    try:
        if not os.getenv("GOOGLE_API_KEY"):
            raise Exception("No Google API key configured")
        
        model = genai.GenerativeModel(GEMINI_MODEL)
        response = model.generate_content(prompt)
        
        if response and hasattr(response, 'text'):
            return response.text.strip()
        else:
            raise Exception("Empty response from Gemini")
            
    except Exception as e:
        logger.error(f"Gemini API error: {e}")
        raise

def call_openai(prompt: str) -> str:
    """Call OpenAI API with error handling"""
    try:
        if not _openai_client:
            raise Exception("OpenAI client not initialized")
        
        response = _openai_client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=500,
            temperature=0.7
        )
        
        if response.choices and len(response.choices) > 0:
            return response.choices[0].message.content.strip()
        else:
            raise Exception("Empty response from OpenAI")
            
    except Exception as e:
        logger.error(f"OpenAI API error: {e}")
        raise

def smart_llm(prompt: str) -> str:
    """Smart LLM with fallback chain"""
    errors = []
    
    # Try Gemini first
    try:
        return call_gemini(prompt)
    except Exception as e:
        errors.append(f"Gemini: {str(e)}")
    
    # Try OpenAI as fallback
    try:
        return call_openai(prompt)
    except Exception as e:
        errors.append(f"OpenAI: {str(e)}")
    
    # Final fallback - rule-based responses
    logger.warning(f"All LLM APIs failed: {'; '.join(errors)}")
    return generate_fallback_response(prompt)

def generate_fallback_response(prompt: str) -> str:
    """Generate intelligent fallback responses when APIs are unavailable"""
    prompt_lower = prompt.lower()
    
    # Greeting patterns
    if any(word in prompt_lower for word in ["hello", "hi", "hey", "good morning", "good afternoon"]):
        return "Hello! I'm your AI companion. I'm currently running in offline mode, but I can still help you with basic tasks and remember our conversations."
    
    # Help patterns
    if any(word in prompt_lower for word in ["help", "what can you do", "capabilities"]):
        return "I can help you with: booking rides, getting movie information, remembering conversations, analyzing images, and more. Just ask!"
    
    # Uber booking patterns
    if any(word in prompt_lower for word in ["uber", "cab", "ride", "book", "taxi"]):
        return "I can help you book an Uber! Just tell me your destination and I'll get you a ride. (Note: This is a demo - I'll simulate the booking process)"
    
    # Movie patterns
    if any(word in prompt_lower for word in ["movie", "film", "watch", "interstellar", "trivia"]):
        return "I love movies! I can provide information about films, trivia, and recommendations. What would you like to know?"
    
    # Memory patterns
    if any(word in prompt_lower for word in ["remember", "memory", "said", "earlier", "before"]):
        return "I'm designed to remember our conversations and provide contextual help. I'll store this interaction for future reference."
    
    # Default response
    return "I understand you said: '" + prompt + "'. I'm currently in offline mode but I'm processing your request and will remember this conversation for future context."


