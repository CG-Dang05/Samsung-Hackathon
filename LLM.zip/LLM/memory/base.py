from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional
from datetime import datetime

@dataclass
class Message:
    """Base class for all types of messages/memories"""
    content: Any
    type: str  # text, image, audio, etc.
    timestamp: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)
    context: Optional[Dict[str, Any]] = None
    embedding: Optional[List[float]] = None

class BaseMemory(ABC):
    """Abstract base class for all memory types"""
    
    @abstractmethod
    def add(self, message: Message) -> bool:
        """Add a new memory/message"""
        pass
    
    @abstractmethod
    def search(self, query: Any, limit: int = 5) -> List[Message]:
        """Search for relevant memories"""
        pass
    
    @abstractmethod
    def clear(self) -> bool:
        """Clear all memories"""
        pass
    
    @abstractmethod
    def get_stats(self) -> Dict[str, Any]:
        """Get memory statistics"""
        pass
    
    def optimize(self) -> bool:
        """Optimize memory storage (optional)"""
        return True
    
    def backup(self, path: str) -> bool:
        """Backup memory to disk (optional)"""
        return True
    
    def restore(self, path: str) -> bool:
        """Restore memory from disk (optional)"""
        return True
