from typing import List, Dict, Any, Optional
import numpy as np
from sentence_transformers import SentenceTransformer
import faiss
import json
from pathlib import Path
import logging
from datetime import datetime

from .base import BaseMemory, Message
from ..config import MEMORY_CONFIG

logger = logging.getLogger(__name__)

class SemanticMemory(BaseMemory):
    """Long-term semantic memory system with efficient retrieval"""
    
    def __init__(self):
        # Initialize sentence transformer
        self.model = SentenceTransformer('all-MiniLM-L6-v2')  # Small, efficient model
        self.dim = self.model.get_sentence_embedding_dimension()
        
        # Initialize FAISS index
        self.index = faiss.IndexFlatIP(self.dim)
        
        # Initialize storage
        self.memories: List[Message] = []
        self.cache_dir = Path(MEMORY_CONFIG["cache_dir"]) / "semantic"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        # Load existing memories
        self._load_memories()
        
        logger.info(f"Initialized SemanticMemory with dimension {self.dim}")

    def add(self, message: Message) -> bool:
        try:
            # Only process text messages
            if message.type != "text" or not isinstance(message.content, str):
                logger.warning("Non-text message passed to SemanticMemory")
                return False
            
            # Generate embedding if not present
            if not message.embedding:
                embedding = self.model.encode(message.content, 
                                           show_progress_bar=False,
                                           convert_to_numpy=True)
                message.embedding = embedding.tolist()
            
            # Add to index and storage
            self.index.add(np.array([message.embedding], dtype=np.float32))
            self.memories.append(message)
            
            # Periodically save to disk
            if len(self.memories) % 100 == 0:
                self._save_memories()
            
            return True
            
        except Exception as e:
            logger.error(f"Error adding to semantic memory: {e}")
            return False

    def search(self, query: Any, limit: int = 5) -> List[Message]:
        try:
            # Handle different query types
            if isinstance(query, str):
                query_embedding = self.model.encode(query, 
                                                 show_progress_bar=False,
                                                 convert_to_numpy=True)
            elif isinstance(query, Message) and query.embedding:
                query_embedding = np.array(query.embedding)
            else:
                logger.warning("Invalid query type for semantic search")
                return []
            
            # Search index
            distances, indices = self.index.search(
                query_embedding.reshape(1, -1),
                min(limit, len(self.memories))
            )
            
            # Return matches above threshold
            results = []
            for dist, idx in zip(distances[0], indices[0]):
                if (dist >= MEMORY_CONFIG["similarity_threshold"] and 
                    0 <= idx < len(self.memories)):
                    results.append(self.memories[idx])
            
            return results
            
        except Exception as e:
            logger.error(f"Error in semantic search: {e}")
            return []

    def clear(self) -> bool:
        try:
            self.memories.clear()
            self.index = faiss.IndexFlatIP(self.dim)
            
            # Clear cache files
            for file in self.cache_dir.glob("*.json"):
                file.unlink()
            
            return True
            
        except Exception as e:
            logger.error(f"Error clearing semantic memory: {e}")
            return False

    def get_stats(self) -> Dict[str, Any]:
        return {
            "memory_count": len(self.memories),
            "vector_dimension": self.dim,
            "index_size": self.index.ntotal,
            "cache_size": sum(f.stat().st_size for f in self.cache_dir.glob("*.json"))
        }

    def _save_memories(self):
        """Save memories to disk"""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            cache_file = self.cache_dir / f"semantic_{timestamp}.json"
            
            # Convert memories to serializable format
            data = []
            for mem in self.memories:
                mem_dict = {
                    "content": mem.content,
                    "type": mem.type,
                    "timestamp": mem.timestamp.isoformat(),
                    "metadata": mem.metadata,
                    "embedding": mem.embedding
                }
                data.append(mem_dict)
            
            # Save to file
            with open(cache_file, 'w') as f:
                json.dump(data, f)
            
            # Clean old cache files
            cache_files = sorted(self.cache_dir.glob("*.json"))
            if len(cache_files) > 5:  # Keep last 5 cache files
                for file in cache_files[:-5]:
                    file.unlink()
                    
        except Exception as e:
            logger.error(f"Error saving semantic memories: {e}")

    def _load_memories(self):
        """Load memories from disk"""
        try:
            cache_files = sorted(self.cache_dir.glob("*.json"))
            if not cache_files:
                return
            
            latest_cache = cache_files[-1]
            
            with open(latest_cache, 'r') as f:
                data = json.load(f)
            
            # Reconstruct memories
            for mem_dict in data:
                message = Message(
                    content=mem_dict["content"],
                    type=mem_dict["type"],
                    timestamp=datetime.fromisoformat(mem_dict["timestamp"]),
                    metadata=mem_dict["metadata"],
                    embedding=mem_dict["embedding"]
                )
                self.memories.append(message)
                
                # Rebuild index
                if message.embedding:
                    self.index.add(np.array([message.embedding], dtype=np.float32))
            
            logger.info(f"Loaded {len(self.memories)} memories from cache")
            
        except Exception as e:
            logger.error(f"Error loading semantic memories: {e}")
