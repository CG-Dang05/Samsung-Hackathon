from typing import Dict, Any, Optional
import json
from pathlib import Path
import logging
from datetime import datetime, timedelta
import zlib
import pickle
from threading import Lock

from ..config import CACHE_CONFIG

logger = logging.getLogger(__name__)

class MemoryCache:
    """Thread-safe caching system for memory optimization"""
    
    def __init__(self):
        self.cache_dir = Path(CACHE_CONFIG["cache_dir"])
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        self.max_size = CACHE_CONFIG["max_size"]
        self.ttl = CACHE_CONFIG["ttl"]
        self.compression = CACHE_CONFIG["compression"]
        
        self._cache: Dict[str, Any] = {}
        self._metadata: Dict[str, Dict[str, Any]] = {}
        self._lock = Lock()
        
        # Load existing cache
        self._load_cache()
        logger.info("Initialized MemoryCache system")

    def get(self, key: str) -> Optional[Any]:
        """Get value from cache with TTL check"""
        with self._lock:
            try:
                if key not in self._metadata:
                    return None
                
                # Check TTL
                metadata = self._metadata[key]
                if datetime.now() - metadata["timestamp"] > timedelta(seconds=self.ttl):
                    self._remove(key)
                    return None
                
                # Update access time
                metadata["last_access"] = datetime.now()
                
                # Decompress if needed
                value = self._cache[key]
                if metadata.get("compressed"):
                    value = zlib.decompress(value)
                    value = pickle.loads(value)
                
                return value
                
            except Exception as e:
                logger.error(f"Error retrieving from cache: {e}")
                return None

    def set(self, key: str, value: Any) -> bool:
        """Set value in cache with size management"""
        with self._lock:
            try:
                # Prepare value for storage
                if self.compression:
                    value = pickle.dumps(value)
                    value = zlib.compress(value)
                
                # Check size
                size = len(value) if isinstance(value, bytes) else len(str(value))
                if size > self.max_size:
                    logger.warning(f"Value too large for cache: {size} bytes")
                    return False
                
                # Make space if needed
                self._ensure_space(size)
                
                # Store value and metadata
                self._cache[key] = value
                self._metadata[key] = {
                    "size": size,
                    "timestamp": datetime.now(),
                    "last_access": datetime.now(),
                    "compressed": self.compression
                }
                
                # Periodic save
                if len(self._cache) % 100 == 0:
                    self._save_cache()
                
                return True
                
            except Exception as e:
                logger.error(f"Error setting cache value: {e}")
                return False

    def remove(self, key: str) -> bool:
        """Remove item from cache"""
        with self._lock:
            return self._remove(key)

    def clear(self) -> bool:
        """Clear all cache data"""
        with self._lock:
            try:
                self._cache.clear()
                self._metadata.clear()
                
                # Clear cache files
                for file in self.cache_dir.glob("*.cache"):
                    file.unlink()
                
                return True
                
            except Exception as e:
                logger.error(f"Error clearing cache: {e}")
                return False

    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        with self._lock:
            return {
                "item_count": len(self._cache),
                "total_size": sum(m["size"] for m in self._metadata.values()),
                "compression": self.compression,
                "max_size": self.max_size,
                "ttl": self.ttl
            }

    def _remove(self, key: str) -> bool:
        """Internal method to remove cache item"""
        try:
            if key in self._cache:
                del self._cache[key]
            if key in self._metadata:
                del self._metadata[key]
            return True
        except Exception as e:
            logger.error(f"Error removing cache item: {e}")
            return False

    def _ensure_space(self, needed_size: int):
        """Ensure there's enough space for new data"""
        current_size = sum(m["size"] for m in self._metadata.values())
        
        while current_size + needed_size > self.max_size and self._metadata:
            # Remove least recently accessed items
            lru_key = min(self._metadata.items(), 
                         key=lambda x: x[1]["last_access"])[0]
            removed_size = self._metadata[lru_key]["size"]
            self._remove(lru_key)
            current_size -= removed_size

    def _save_cache(self):
        """Save cache to disk"""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            cache_file = self.cache_dir / f"cache_{timestamp}.cache"
            
            # Prepare serializable data
            data = {
                "metadata": {
                    k: {**v, "timestamp": v["timestamp"].isoformat(),
                        "last_access": v["last_access"].isoformat()}
                    for k, v in self._metadata.items()
                },
                "cache": {
                    k: v.hex() if isinstance(v, bytes) else v
                    for k, v in self._cache.items()
                }
            }
            
            # Save compressed
            with open(cache_file, 'wb') as f:
                pickle.dump(data, f)
            
            # Clean old cache files
            cache_files = sorted(self.cache_dir.glob("*.cache"))
            if len(cache_files) > 5:  # Keep last 5 cache files
                for file in cache_files[:-5]:
                    file.unlink()
                    
        except Exception as e:
            logger.error(f"Error saving cache: {e}")

    def _load_cache(self):
        """Load cache from disk"""
        try:
            cache_files = sorted(self.cache_dir.glob("*.cache"))
            if not cache_files:
                return
            
            latest_cache = cache_files[-1]
            
            with open(latest_cache, 'rb') as f:
                data = pickle.load(f)
            
            # Restore metadata
            self._metadata = {
                k: {**v,
                    "timestamp": datetime.fromisoformat(v["timestamp"]),
                    "last_access": datetime.fromisoformat(v["last_access"])}
                for k, v in data["metadata"].items()
            }
            
            # Restore cache data
            self._cache = {
                k: bytes.fromhex(v) if isinstance(v, str) else v
                for k, v in data["cache"].items()
            }
            
            logger.info(f"Loaded {len(self._cache)} items from cache")
            
        except Exception as e:
            logger.error(f"Error loading cache: {e}")
