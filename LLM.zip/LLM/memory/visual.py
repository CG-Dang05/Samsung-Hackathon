import torch
import torchvision.models as models
import torchvision.transforms as transforms
from PIL import Image
import io
import numpy as np
from typing import List, Dict, Any, Optional
from pathlib import Path
import logging

from .base import BaseMemory, Message
from ..config import MODEL_CONFIG, MEMORY_CONFIG

logger = logging.getLogger(__name__)

class VisualMemory(BaseMemory):
    """Visual memory system using efficient mobile-friendly models"""
    
    def __init__(self):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # Load efficient mobile model
        self.model = models.mobilenet_v3_small(pretrained=True)
        self.model.eval()
        self.model = self.model.to(self.device)
        
        # Setup image preprocessing
        self.transform = transforms.Compose([
            transforms.Resize(MODEL_CONFIG["vision_model"]["image_size"]),
            transforms.CenterCrop(MODEL_CONFIG["vision_model"]["image_size"]),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], 
                              std=[0.229, 0.224, 0.225])
        ])
        
        # Initialize storage
        self.cache_dir = Path(MEMORY_CONFIG["cache_dir"]) / "visual"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        self.memories: List[Message] = []
        logger.info("Initialized VisualMemory system")

    def process_image(self, image_data: bytes) -> Optional[torch.Tensor]:
        """Process image data into embeddings"""
        try:
            # Convert bytes to PIL Image
            image = Image.open(io.BytesIO(image_data))
            
            # Convert to RGB if needed
            if image.mode != 'RGB':
                image = image.convert('RGB')
            
            # Preprocess
            input_tensor = self.transform(image)
            input_batch = input_tensor.unsqueeze(0).to(self.device)
            
            # Generate embedding
            with torch.no_grad():
                embedding = self.model.features(input_batch)
                embedding = torch.nn.functional.adaptive_avg_pool2d(embedding, (1, 1))
                embedding = embedding.squeeze()
            
            return embedding.cpu().numpy()
            
        except Exception as e:
            logger.error(f"Error processing image: {e}")
            return None

    def add(self, message: Message) -> bool:
        try:
            if message.type != "image":
                logger.warning("Non-image message passed to VisualMemory")
                return False
            
            # Process image if not already processed
            if not message.embedding:
                embedding = self.process_image(message.content)
                if embedding is None:
                    return False
                message.embedding = embedding.tolist()
            
            # Store memory
            self.memories.append(message)
            
            # Save image data to cache
            if len(self.memories) % 10 == 0:
                self._cache_images()
            
            return True
            
        except Exception as e:
            logger.error(f"Error adding visual memory: {e}")
            return False

    def search(self, query: Any, limit: int = 5) -> List[Message]:
        try:
            if isinstance(query, bytes):
                # Process query image
                query_embedding = self.process_image(query)
                if query_embedding is None:
                    return []
            elif isinstance(query, Message) and query.embedding:
                query_embedding = np.array(query.embedding)
            else:
                logger.warning("Invalid query type for visual search")
                return []
            
            # Calculate similarities
            similarities = []
            for memory in self.memories:
                if memory.embedding:
                    similarity = np.dot(query_embedding, np.array(memory.embedding))
                    similarities.append((similarity, memory))
            
            # Sort by similarity
            similarities.sort(reverse=True)
            return [mem for _, mem in similarities[:limit]]
            
        except Exception as e:
            logger.error(f"Error in visual search: {e}")
            return []

    def clear(self) -> bool:
        try:
            self.memories.clear()
            
            # Clear cache
            for file in self.cache_dir.glob("*.jpg"):
                file.unlink()
            
            return True
            
        except Exception as e:
            logger.error(f"Error clearing visual memory: {e}")
            return False

    def get_stats(self) -> Dict[str, Any]:
        return {
            "memory_count": len(self.memories),
            "cache_size": sum(f.stat().st_size for f in self.cache_dir.glob("*.jpg")),
            "device": str(self.device),
            "model": "mobilenet_v3_small"
        }

    def _cache_images(self):
        """Cache images to disk"""
        try:
            # Only cache uncached images
            for i, memory in enumerate(self.memories):
                if not memory.metadata.get("cached"):
                    cache_path = self.cache_dir / f"img_{memory.timestamp:%Y%m%d_%H%M%S}_{i}.jpg"
                    
                    # Save image
                    Image.open(io.BytesIO(memory.content)).save(cache_path, "JPEG")
                    
                    # Update metadata
                    memory.metadata["cached"] = True
                    memory.metadata["cache_path"] = str(cache_path)
            
            # Clean old cache files (keep last 1000)
            cache_files = sorted(self.cache_dir.glob("*.jpg"))
            if len(cache_files) > 1000:
                for file in cache_files[:-1000]:
                    file.unlink()
                    
        except Exception as e:
            logger.error(f"Error caching images: {e}")
