import numpy as np
import faiss
import joblib
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import logging
from pathlib import Path

from .base import BaseMemory, Message
from ..config import MEMORY_CONFIG, CACHE_DIR

logger = logging.getLogger(__name__)

class ConversationMemory(BaseMemory):
    """Enhanced conversation memory with efficient storage and retrieval"""
    
    def __init__(self):
        self.dim = MEMORY_CONFIG["vector_dim"]
        self.max_docs = MEMORY_CONFIG["max_documents"]
        self.threshold = MEMORY_CONFIG["similarity_threshold"]
        
        # Initialize FAISS index
        self.index = faiss.IndexFlatIP(self.dim)
        self.vectors: List[np.ndarray] = []
        self.messages: List[Message] = []
        
        # Initialize cache
        self.cache_path = Path(MEMORY_CONFIG["cache_dir"]) / "conversation"
        self.cache_path.mkdir(parents=True, exist_ok=True)
        
        # Load existing cache if available
        self._load_cache()
        
        logger.info(f"Initialized ConversationMemory with dimension {self.dim}")

    def add(self, message: Message) -> bool:
        try:
            if not message.embedding:
                logger.warning("Message has no embedding")
                return False
                
            vec = np.array(message.embedding, dtype=np.float32)
            
            # Add to FAISS index
            self.index.add(vec.reshape(1, -1))
            
            # Store message and vector
            self.vectors.append(vec)
            self.messages.append(message)
            
            # Optimize if needed
            if len(self.messages) > self.max_docs:
                self._compress_memory()
            
            # Cache periodically
            if len(self.messages) % 10 == 0:
                self._save_cache()
            
            return True
            
        except Exception as e:
            logger.error(f"Error adding message: {e}")
            return False

    def search(self, query: Any, limit: int = 5) -> List[Message]:
        try:
            if isinstance(query, str) and not query.strip():
                return []
            
            if isinstance(query, Message):
                query_vec = np.array(query.embedding, dtype=np.float32).reshape(1, -1)
            else:
                logger.warning("Unsupported query type")
                return []
            
            # Search similar vectors
            limit = min(limit, len(self.messages))
            distances, indices = self.index.search(query_vec, limit)
            
            # Filter by similarity threshold
            results = []
            for dist, idx in zip(distances[0], indices[0]):
                if dist >= self.threshold and 0 <= idx < len(self.messages):
                    results.append(self.messages[idx])
            
            return results
            
        except Exception as e:
            logger.error(f"Error searching messages: {e}")
            return []

    def clear(self) -> bool:
        try:
            self.index = faiss.IndexFlatIP(self.dim)
            self.vectors = []
            self.messages = []
            
            # Clear cache
            for file in self.cache_path.glob("*.cache"):
                file.unlink()
            
            return True
            
        except Exception as e:
            logger.error(f"Error clearing memory: {e}")
            return False

    def get_stats(self) -> Dict[str, Any]:
        return {
            "message_count": len(self.messages),
            "vector_dimension": self.dim,
            "index_size": self.index.ntotal,
            "cache_size": sum(f.stat().st_size for f in self.cache_path.glob("*.cache")),
            "last_message": self.messages[-1].timestamp if self.messages else None
        }

    def _compress_memory(self):
        """Compress memory by removing old or less relevant messages"""
        if len(self.messages) <= self.max_docs:
            return
            
        # Keep recent messages
        keep_recent = int(self.max_docs * 0.3)
        recent_msgs = self.messages[-keep_recent:]
        recent_vecs = self.vectors[-keep_recent:]
        
        # Score remaining messages by relevance and recency
        remaining = self.messages[:-keep_recent]
        scores = []
        
        now = datetime.now()
        for msg in remaining:
            age_hours = (now - msg.timestamp).total_seconds() / 3600
            age_score = 1 / (1 + age_hours)
            
            relevance_score = 0
            if msg.metadata.get("importance"):
                relevance_score = float(msg.metadata["importance"])
            
            scores.append(0.7 * age_score + 0.3 * relevance_score)
        
        # Keep highest scoring messages
        keep_count = self.max_docs - keep_recent
        keep_indices = np.argsort(scores)[-keep_count:]
        
        keep_msgs = [remaining[i] for i in keep_indices]
        keep_vecs = [self.vectors[i] for i in keep_indices]
        
        # Update storage
        self.messages = keep_msgs + recent_msgs
        self.vectors = keep_vecs + recent_vecs
        
        # Rebuild index
        self.index = faiss.IndexFlatIP(self.dim)
        self.index.add(np.vstack(self.vectors))
        
        logger.info(f"Compressed memory from {len(remaining) + keep_recent} to {len(self.messages)} messages")

    def _save_cache(self):
        """Save memory state to cache"""
        try:
            cache_file = self.cache_path / f"memory_{datetime.now().strftime('%Y%m%d_%H%M%S')}.cache"
            
            state = {
                "messages": self.messages,
                "vectors": self.vectors,
                "timestamp": datetime.now()
            }
            
            joblib.dump(state, cache_file)
            
            # Clean old cache files
            for file in sorted(self.cache_path.glob("*.cache"))[:-5]:  # Keep last 5 caches
                file.unlink()
                
        except Exception as e:
            logger.error(f"Error saving cache: {e}")

    def _load_cache(self):
        """Load most recent cache"""
        try:
            cache_files = sorted(self.cache_path.glob("*.cache"))
            if not cache_files:
                return
                
            latest_cache = cache_files[-1]
            state = joblib.load(latest_cache)
            
            if datetime.now() - state["timestamp"] > timedelta(days=7):
                logger.warning("Cache is more than 7 days old")
                return
                
            self.messages = state["messages"]
            self.vectors = state["vectors"]
            
            self.index = faiss.IndexFlatIP(self.dim)
            self.index.add(np.vstack(self.vectors))
            
            logger.info(f"Loaded {len(self.messages)} messages from cache")
        except Exception as e:
            logger.error(f"Error loading cache: {e}")
