from typing import Dict, Any, List
import re
import logging

logger = logging.getLogger(__name__)

def plan_task(user_text: str) -> Dict[str, Any]:
    """Enhanced task planning with better intent recognition"""
    try:
        text_lower = user_text.lower().strip()
        
        # Uber booking patterns
        if any(word in text_lower for word in ["uber", "cab", "taxi", "ride"]) and any(word in text_lower for word in ["book", "call", "get", "order"]):
            destination = extract_destination(text_lower)
            return {
                "action": "BOOK_UBER",
                "destination": destination,
                "needs_confirmation": True,
                "confidence": 0.9,
                "extracted_info": {
                    "service": "uber",
                    "destination": destination,
                    "urgency": "normal"
                }
            }
        
        # Movie/Entertainment patterns
        if any(word in text_lower for word in ["movie", "film", "watch", "streaming"]):
            movie_name = extract_movie_name(text_lower)
            return {
                "action": "MOVIE_INFO",
                "movie": movie_name,
                "needs_confirmation": False,
                "confidence": 0.8,
                "extracted_info": {
                    "type": "entertainment",
                    "movie": movie_name,
                    "query_type": "info"
                }
            }
        
        # Interstellar specific
        if "interstellar" in text_lower:
            return {
                "action": "INTERSTELLAR_INFO",
                "needs_confirmation": False,
                "confidence": 0.95,
                "extracted_info": {
                    "type": "movie_trivia",
                    "movie": "Interstellar",
                    "query_type": "trivia"
                }
            }
        
        # Reminder patterns
        if any(word in text_lower for word in ["remind", "reminder", "remember", "alert"]):
            reminder_text = extract_reminder_text(text_lower)
            return {
                "action": "SET_REMINDER",
                "reminder": reminder_text,
                "needs_confirmation": True,
                "confidence": 0.7,
                "extracted_info": {
                    "type": "reminder",
                    "text": reminder_text,
                    "urgency": "normal"
                }
            }
        
        # Search patterns
        if any(word in text_lower for word in ["search", "find", "look up", "google"]):
            search_query = extract_search_query(text_lower)
            return {
                "action": "SEARCH",
                "query": search_query,
                "needs_confirmation": False,
                "confidence": 0.6,
                "extracted_info": {
                    "type": "search",
                    "query": search_query,
                    "engine": "google"
                }
            }
        
        # Default chat action
        return {
            "action": "CHAT",
            "needs_confirmation": False,
            "confidence": 0.5,
            "extracted_info": {
                "type": "conversation",
                "intent": "chat"
            }
        }
        
    except Exception as e:
        logger.error(f"Error in task planning: {e}")
        return {
            "action": "CHAT",
            "needs_confirmation": False,
            "confidence": 0.1,
            "error": str(e)
        }

def extract_destination(text: str) -> str:
    """Extract destination from text"""
    # Common destination patterns
    destinations = [
        "connaught place", "cp", "airport", "station", "mall", "hospital",
        "office", "home", "work", "gym", "restaurant", "hotel"
    ]
    
    for dest in destinations:
        if dest in text:
            return dest
    
    # Try to extract location after "to" or "for"
    patterns = [
        r"to\s+([a-zA-Z\s]+?)(?:\s|$)",
        r"for\s+([a-zA-Z\s]+?)(?:\s|$)",
        r"destination\s+([a-zA-Z\s]+?)(?:\s|$)"
    ]
    
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            return match.group(1).strip()
    
    return "destination"

def extract_movie_name(text: str) -> str:
    """Extract movie name from text"""
    # Remove common words
    text = re.sub(r'\b(about|info|information|trivia|details)\b', '', text)
    text = text.strip()
    
    if "interstellar" in text:
        return "Interstellar"
    
    # Try to extract movie name after "movie" or "film"
    patterns = [
        r"movie\s+([a-zA-Z\s]+?)(?:\s|$)",
        r"film\s+([a-zA-Z\s]+?)(?:\s|$)",
        r"watch\s+([a-zA-Z\s]+?)(?:\s|$)"
    ]
    
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            return match.group(1).strip()
    
    return "movie"

def extract_reminder_text(text: str) -> str:
    """Extract reminder text"""
    # Remove reminder keywords
    text = re.sub(r'\b(remind|reminder|remember|alert)\b', '', text)
    text = text.strip()
    
    if not text:
        return "reminder"
    
    return text

def extract_search_query(text: str) -> str:
    """Extract search query"""
    # Remove search keywords
    text = re.sub(r'\b(search|find|look up|google)\b', '', text)
    text = text.strip()
    
    if not text:
        return "search"
    
    return text

def run_task(task: Dict[str, Any]) -> Dict[str, Any]:
    """Enhanced task execution with better responses"""
    try:
        action = task.get("action", "CHAT")
        confidence = task.get("confidence", 0.5)
        
        if action == "BOOK_UBER":
            destination = task.get("destination", "destination")
            price_range = get_uber_price(destination)
            
            return {
                "summary": f"🚗 Uber to {destination.title()}: {price_range}\n\nReady to book? I'll need your confirmation.",
                "requires_user_confirmation": True,
                "details": {
                    "service": "Uber",
                    "destination": destination,
                    "price_range": price_range,
                    "estimated_time": "5-10 minutes"
                },
                "next_action": "confirm_booking"
            }
        
        elif action == "INTERSTELLAR_INFO":
            return {
                "summary": "🎬 **Interstellar (2014)**\n\n**Director:** Christopher Nolan\n**Cast:** Matthew McConaughey, Anne Hathaway, Jessica Chastain\n\n**Trivia:**\n• Kip Thorne (Nobel physicist) was scientific consultant\n• TARS and CASE robots inspired by 2001: A Space Odyssey\n• Hans Zimmer's organ score recorded in London's Temple Church\n• Practical effects used for zero-gravity scenes\n• 70mm IMAX footage for space sequences",
                "requires_user_confirmation": False,
                "details": {
                    "type": "movie_info",
                    "movie": "Interstellar",
                    "year": 2014,
                    "rating": "8.6/10 IMDb"
                }
            }
        
        elif action == "MOVIE_INFO":
            movie = task.get("movie", "movie")
            return {
                "summary": f"🎬 I can help you with information about {movie.title()}! What would you like to know - cast, plot, reviews, or where to watch it?",
                "requires_user_confirmation": False,
                "details": {
                    "type": "movie_query",
                    "movie": movie
                }
            }
        
        elif action == "SET_REMINDER":
            reminder_text = task.get("reminder", "reminder")
            return {
                "summary": f"⏰ Reminder set: {reminder_text}\n\nI'll remind you about this. (Note: This is a demo - reminders are simulated)",
                "requires_user_confirmation": False,
                "details": {
                    "type": "reminder",
                    "text": reminder_text,
                    "status": "set"
                }
            }
        
        elif action == "SEARCH":
            query = task.get("query", "search")
            return {
                "summary": f"🔍 Searching for: {query}\n\nI can help you find information about this. What specific details are you looking for?",
                "requires_user_confirmation": False,
                "details": {
                    "type": "search",
                    "query": query,
                    "status": "ready"
                }
            }
        
        else:  # CHAT
            return {
                "summary": "I understand your message and I'm here to help! What would you like to do?",
                "requires_user_confirmation": False,
                "details": {
                    "type": "conversation",
                    "intent": "chat"
                }
            }
            
    except Exception as e:
        logger.error(f"Error in task execution: {e}")
        return {
            "summary": "I encountered an error while processing your request. Please try again.",
            "requires_user_confirmation": False,
            "error": str(e)
        }

def get_uber_price(destination: str) -> str:
    """Get simulated Uber price for destination"""
    prices = {
        "connaught place": "₹210 - ₹270",
        "cp": "₹210 - ₹270", 
        "airport": "₹450 - ₹600",
        "station": "₹180 - ₹250",
        "mall": "₹150 - ₹200",
        "hospital": "₹200 - ₹280",
        "office": "₹120 - ₹180",
        "home": "₹100 - ₹150",
        "work": "₹120 - ₹180",
        "gym": "₹80 - ₹120",
        "restaurant": "₹90 - ₹140",
        "hotel": "₹150 - ₹220"
    }
    
    return prices.get(destination.lower(), "₹150 - ₹250")


