from typing import List, Dict, Any
from dataclasses import dataclass, field
import faiss
import numpy as np
import hashlib
import logging

logger = logging.getLogger(__name__)

@dataclass
class Message:
    role: str
    text: str
    meta: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=lambda: np.datetime64('now').astype(float))

class ConversationMemory:
    def __init__(self, dim: int = 384):
        self.dim = dim
        self.index = faiss.IndexFlatIP(dim)
        self.vectors: List[np.ndarray] = []
        self.messages: List[Message] = []
        self.message_count = 0
        
        logger.info(f"Initialized ConversationMemory with dimension {dim}")

    def embed(self, text: str) -> np.ndarray:
        """Generate deterministic embeddings for text"""
        try:
            # Create a hash-based seed for reproducibility
            text_hash = hashlib.md5(text.encode()).hexdigest()
            seed = int(text_hash[:8], 16)
            
            # Generate pseudo-random vector based on text content
            rng = np.random.default_rng(seed)
            vector = rng.normal(0, 1, self.dim).astype(np.float32)
            
            # Normalize the vector
            norm = np.linalg.norm(vector)
            if norm > 0:
                vector /= norm
            
            return vector
            
        except Exception as e:
            logger.error(f"Error generating embedding: {e}")
            # Fallback to zero vector
            return np.zeros(self.dim, dtype=np.float32)

    def add(self, msg: Message):
        """Add a message to memory"""
        try:
            if not msg.text or not msg.text.strip():
                logger.warning("Attempted to add empty message")
                return
                
            vec = self.embed(msg.text)
            
            # Add to FAISS index
            self.index.add(vec.reshape(1, -1))
            
            # Store vectors and messages
            self.vectors.append(vec)
            self.messages.append(msg)
            self.message_count += 1
            
            logger.debug(f"Added message {self.message_count}: {msg.role} - {msg.text[:50]}...")
            
        except Exception as e:
            logger.error(f"Error adding message to memory: {e}")

    def similar(self, query: str, k: int = 5) -> List[Message]:
        """Find similar messages to the query"""
        try:
            if len(self.messages) == 0:
                return []
            
            if not query or not query.strip():
                return []
            
            # Generate query embedding
            query_vec = self.embed(query).reshape(1, -1)
            
            # Search for similar vectors
            k = min(k, len(self.messages))
            distances, indices = self.index.search(query_vec, k)
            
            # Return messages for valid indices
            similar_messages = []
            for idx in indices[0]:
                if 0 <= idx < len(self.messages):
                    similar_messages.append(self.messages[idx])
            
            logger.debug(f"Found {len(similar_messages)} similar messages for query: {query[:30]}...")
            return similar_messages
            
        except Exception as e:
            logger.error(f"Error finding similar messages: {e}")
            return []

    def get_recent(self, n: int = 10) -> List[Message]:
        """Get the most recent messages"""
        try:
            return self.messages[-n:] if self.messages else []
        except Exception as e:
            logger.error(f"Error getting recent messages: {e}")
            return []

    def get_context_summary(self, query: str = None) -> str:
        """Get a summary of relevant context"""
        try:
            if query:
                similar = self.similar(query, k=3)
                if similar:
                    context = "\n".join([f"{msg.role}: {msg.text}" for msg in similar])
                    return f"Relevant context:\n{context}"
            
            # Fallback to recent messages
            recent = self.get_recent(5)
            if recent:
                context = "\n".join([f"{msg.role}: {msg.text}" for msg in recent])
                return f"Recent context:\n{context}"
            
            return "No previous context available."
            
        except Exception as e:
            logger.error(f"Error generating context summary: {e}")
            return "Error retrieving context."

    def clear(self):
        """Clear all memory"""
        try:
            self.index = faiss.IndexFlatIP(self.dim)
            self.vectors.clear()
            self.messages.clear()
            self.message_count = 0
            logger.info("Memory cleared")
        except Exception as e:
            logger.error(f"Error clearing memory: {e}")

    def get_stats(self) -> Dict[str, Any]:
        """Get memory statistics"""
        return {
            "total_messages": self.message_count,
            "current_messages": len(self.messages),
            "index_size": self.index.ntotal if hasattr(self.index, 'ntotal') else 0,
            "dimension": self.dim
        }


