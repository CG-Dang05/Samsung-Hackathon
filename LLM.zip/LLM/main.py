import io
import os
import logging
from typing import Optional, List, Dict, Any
from datetime import datetime

from fastapi import FastAPI, UploadFile, File, Form, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from dotenv import load_dotenv

import numpy as np
import cv2
from PIL import Image

import asyncio
from memory import (
    ConversationMemory, 
    VisualMemory, 
    SemanticMemory,
    MemoryCache,
    Message
)
from llm import init_llms, smart_llm
from tools import plan_task, run_task
from config import FEATURES, API_CONFIG

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

# Initialize FastAPI app
app = FastAPI(
    title="Untethered AI Companion Backend",
    description="A sophisticated AI backend for the Untethered AI Companion Android app",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize components
_openai = init_llms()
conversation_memory = ConversationMemory()
visual_memory = VisualMemory()
semantic_memory = SemanticMemory()
cache = MemoryCache()

# WebSocket connections
active_connections = set()

# Background task queue
task_queue = asyncio.Queue()

# Pydantic models
class ChatIn(BaseModel):
    text: str = Field(..., min_length=1, max_length=1000, description="User message")
    context: Optional[List[str]] = Field(default=None, description="Additional context")

class TaskIn(BaseModel):
    text: str = Field(..., min_length=1, max_length=1000, description="Task description")
    confirm: Optional[bool] = Field(default=None, description="Confirmation flag")

class VisionIn(BaseModel):
    description: Optional[str] = Field(default=None, description="Image description")

class HealthResponse(BaseModel):
    status: str = "healthy"
    timestamp: str
    memory_stats: Dict[str, Any]
    llm_status: str

@app.get("/", response_class=HTMLResponse)
async def root():
    """Serve the main HTML interface"""
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Untethered AI Companion - Backend</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                padding: 20px;
            }
            .container {
                max-width: 1200px;
                margin: 0 auto;
                background: white;
                border-radius: 20px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.1);
                overflow: hidden;
            }
            .header {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 30px;
                text-align: center;
            }
            .header h1 {
                font-size: 2.5em;
                margin-bottom: 10px;
            }
            .header p {
                font-size: 1.2em;
                opacity: 0.9;
            }
            .content {
                padding: 30px;
            }
            .section {
                margin-bottom: 30px;
                padding: 20px;
                border: 1px solid #e0e0e0;
                border-radius: 10px;
                background: #fafafa;
            }
            .section h3 {
                color: #333;
                margin-bottom: 15px;
                font-size: 1.3em;
            }
            textarea {
                width: 100%;
                height: 100px;
                padding: 15px;
                border: 2px solid #e0e0e0;
                border-radius: 10px;
                font-size: 16px;
                resize: vertical;
                font-family: inherit;
            }
            textarea:focus {
                outline: none;
                border-color: #667eea;
            }
            .button-group {
                display: flex;
                gap: 10px;
                margin: 15px 0;
                flex-wrap: wrap;
            }
            button {
                padding: 12px 24px;
                border: none;
                border-radius: 8px;
                font-size: 16px;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s ease;
                min-width: 120px;
            }
            .btn-primary {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
            }
            .btn-secondary {
                background: #6c757d;
                color: white;
            }
            .btn-success {
                background: #28a745;
                color: white;
            }
            .btn-warning {
                background: #ffc107;
                color: #212529;
            }
            button:hover {
                transform: translateY(-2px);
                box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            }
            .output {
                background: #f8f9fa;
                border: 1px solid #dee2e6;
                border-radius: 10px;
                padding: 20px;
                margin-top: 20px;
                font-family: 'Courier New', monospace;
                white-space: pre-wrap;
                max-height: 400px;
                overflow-y: auto;
            }
            .status {
                display: inline-block;
                padding: 5px 10px;
                border-radius: 15px;
                font-size: 12px;
                font-weight: bold;
                text-transform: uppercase;
            }
            .status.online { background: #d4edda; color: #155724; }
            .status.offline { background: #f8d7da; color: #721c24; }
            .features {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 20px;
                margin-top: 20px;
            }
            .feature {
                background: white;
                padding: 20px;
                border-radius: 10px;
                border-left: 4px solid #667eea;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            .feature h4 {
                color: #667eea;
                margin-bottom: 10px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🤖 Untethered AI Companion</h1>
                <p>Advanced AI Backend for Always-On Assistant</p>
                <div style="margin-top: 15px;">
                    <span class="status online">Backend Online</span>
                    <span class="status online">Memory Active</span>
                    <span class="status online">LLM Ready</span>
                </div>
            </div>
            
            <div class="content">
                <div class="features">
                    <div class="feature">
                        <h4>🎯 Smart Task Planning</h4>
                        <p>Intelligent intent recognition for Uber booking, movie info, reminders, and more.</p>
                    </div>
                    <div class="feature">
                        <h4>🧠 Conversation Memory</h4>
                        <p>FAISS-powered semantic memory for contextual conversations.</p>
                    </div>
                    <div class="feature">
                        <h4>🔍 Vision Analysis</h4>
                        <p>OpenCV-based image processing and analysis capabilities.</p>
                    </div>
                    <div class="feature">
                        <h4>⚡ Multi-LLM Support</h4>
                        <p>Gemini + OpenAI fallback with intelligent offline responses.</p>
                    </div>
                </div>

                <div class="section">
                    <h3>💬 Chat Interface</h3>
                    <textarea id="chatInput" placeholder="Type your message here..."></textarea>
                    <div class="button-group">
                        <button class="btn-primary" onclick="sendChat()">Send Chat</button>
                        <button class="btn-secondary" onclick="sendTask()">Send Task</button>
                        <button class="btn-success" onclick="clearOutput()">Clear Output</button>
                    </div>
                    <div class="output" id="chatOutput">Ready to chat! Try: "Hello", "Book an Uber to Connaught Place", or "Interstellar trivia"</div>
                </div>

                <div class="section">
                    <h3>📊 System Status</h3>
                    <div class="button-group">
                        <button class="btn-warning" onclick="checkHealth()">Check Health</button>
                        <button class="btn-secondary" onclick="getMemoryStats()">Memory Stats</button>
                        <button class="btn-secondary" onclick="clearMemory()">Clear Memory</button>
                    </div>
                    <div class="output" id="statusOutput">Click "Check Health" to see system status</div>
                </div>
            </div>
        </div>

        <script>
            const base = window.location.origin;
            
            async function sendChat() {
                const text = document.getElementById('chatInput').value;
                if (!text.trim()) return;
                
                try {
                    const response = await fetch(`${base}/chat`, {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({text: text})
                    });
                    const result = await response.json();
                    document.getElementById('chatOutput').textContent = JSON.stringify(result, null, 2);
                } catch (error) {
                    document.getElementById('chatOutput').textContent = 'Error: ' + error.message;
                }
            }
            
            async function sendTask() {
                const text = document.getElementById('chatInput').value;
                if (!text.trim()) return;
                
                try {
                    const response = await fetch(`${base}/task`, {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({text: text})
                    });
                    const result = await response.json();
                    document.getElementById('chatOutput').textContent = JSON.stringify(result, null, 2);
                } catch (error) {
                    document.getElementById('chatOutput').textContent = 'Error: ' + error.message;
                }
            }
            
            async function checkHealth() {
                try {
                    const response = await fetch(`${base}/health`);
                    const result = await response.json();
                    document.getElementById('statusOutput').textContent = JSON.stringify(result, null, 2);
                } catch (error) {
                    document.getElementById('statusOutput').textContent = 'Error: ' + error.message;
                }
            }
            
            async function getMemoryStats() {
                try {
                    const response = await fetch(`${base}/memory/stats`);
                    const result = await response.json();
                    document.getElementById('statusOutput').textContent = JSON.stringify(result, null, 2);
                } catch (error) {
                    document.getElementById('statusOutput').textContent = 'Error: ' + error.message;
                }
            }
            
            async function clearMemory() {
                try {
                    const response = await fetch(`${base}/memory/clear`, {method: 'POST'});
                    const result = await response.json();
                    document.getElementById('statusOutput').textContent = JSON.stringify(result, null, 2);
                } catch (error) {
                    document.getElementById('statusOutput').textContent = 'Error: ' + error.message;
                }
            }
            
            function clearOutput() {
                document.getElementById('chatOutput').textContent = '';
                document.getElementById('statusOutput').textContent = '';
            }
            
            // Auto-focus on input
            document.getElementById('chatInput').focus();
            
            // Enter key to send chat
            document.getElementById('chatInput').addEventListener('keypress', function(e) {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    sendChat();
                }
            });
        </script>
    </body>
    </html>
    """

@app.get("/health", response_model=HealthResponse)
async def health():
    """Health check endpoint"""
    try:
        memory_stats = conversation_memory.get_stats()
        llm_status = "online" if os.getenv("GOOGLE_API_KEY") or os.getenv("OPENAI_API_KEY") else "offline"
        
        return HealthResponse(
            status="healthy",
            timestamp=datetime.now().isoformat(),
            memory_stats=memory_stats,
            llm_status=llm_status
        )
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/listen")
async def listen(
    text: Optional[str] = Form(None),
    audio: Optional[UploadFile] = File(None)
):
    """Process audio or text input from the Android app"""
    try:
        if text:
            conversation_memory.add(Message(role="user", text=text))
            logger.info(f"Received text input: {text[:50]}...")
            return {"ok": True, "asr": text, "timestamp": datetime.now().isoformat()}
        
        if audio:
            # Placeholder for speech-to-text processing
            audio_content = await audio.read()
            logger.info(f"Received audio file: {len(audio_content)} bytes")
            conversation_memory.add(Message(role="user", text="[audio message]"))
            return {
                "ok": True,
                "asr": "[transcribed speech placeholder]",
                "audio_size": len(audio_content),
                "timestamp": datetime.now().isoformat()
            }
        
        raise HTTPException(status_code=400, detail="Provide text or audio")
        
    except Exception as e:
        logger.error(f"Error in listen endpoint: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/vision")
async def vision(image: UploadFile = File(...)):
    """Process image input for vision analysis"""
    try:
        if not image.content_type.startswith('image/'):
            raise HTTPException(status_code=400, detail="File must be an image")
        
        data = await image.read()
        arr = np.frombuffer(data, dtype=np.uint8)
        frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        
        if frame is None:
            raise HTTPException(status_code=400, detail="Invalid image format")
        
        # Basic image analysis
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        blur = float(cv2.Laplacian(gray, cv2.CV_64F).var())
        color_mean = [float(x) for x in frame.mean(axis=(0, 1)).tolist()]
        
        # Enhanced analysis
        height, width = frame.shape[:2]
        aspect_ratio = width / height if height > 0 else 0
        
        description = f"Image analysis: {width}x{height}px, blur:{blur:.2f}, colors(BGR):{[round(c,2) for c in color_mean]}, aspect:{aspect_ratio:.2f}"
        
        visual_memory.add(Message(role="vision", text=description))
        logger.info(f"Processed image: {description}")
        
        return {
            "ok": True,
            "description": description,
            "analysis": {
                "dimensions": {"width": width, "height": height},
                "blur_score": round(blur, 2),
                "color_mean": [round(c, 2) for c in color_mean],
                "aspect_ratio": round(aspect_ratio, 2)
            },
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error in vision endpoint: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/chat")
async def chat(payload: ChatIn):
    """Process chat messages with memory and LLM"""
    try:
        user_text = payload.text.strip()
        if not user_text:
            raise HTTPException(status_code=400, detail="Empty message")
        
        # Get relevant context from memory
        similar_messages = conversation_memory.similar(user_text, k=5)
        context_snippets = "\n".join([f"- {m.role}: {m.text}" for m in similar_messages])
        
        # Create enhanced prompt
        prompt = f"""You are an intelligent AI assistant for the Untethered AI Companion app.

User message: {user_text}

Relevant conversation history:
{context_snippets if context_snippets else '(No previous context)'}

Provide a helpful, contextual response. Be concise but informative."""

        # Get LLM response
        reply = smart_llm(prompt)
        
        # Store in memory
        conversation_memory.add(Message(role="user", text=user_text))
        conversation_memory.add(Message(role="assistant", text=reply))
        
        logger.info(f"Chat processed: {user_text[:50]}... -> {reply[:50]}...")
        
        return {
            "ok": True,
            "reply": reply,
            "used_memory": len(similar_messages),
            "context_snippets": [f"{m.role}: {m.text}" for m in similar_messages],
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error in chat endpoint: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/task")
async def task(payload: TaskIn):
    """Execute tasks with planning and confirmation"""
    try:
        user_text = payload.text.strip()
        if not user_text:
            raise HTTPException(status_code=400, detail="Empty task")
        
        # Plan the task
        plan = plan_task(user_text)
        logger.info(f"Task planned: {plan}")
        
        # Check if confirmation is needed
        if plan.get("needs_confirmation") and payload.confirm is not True:
            # Return plan for user confirmation
            result = run_task(plan)
            return {
                "ok": True,
                "require_confirmation": True,
                "summary": result["summary"],
                "plan": plan,
                "confidence": plan.get("confidence", 0.5),
                "timestamp": datetime.now().isoformat()
            }
        
        # Execute the task
        result = run_task(plan)
        
        # Store in memory
        conversation_memory.add(Message(role="user", text=user_text))
        conversation_memory.add(Message(role="assistant", text=result["summary"]))
        
        logger.info(f"Task executed: {user_text[:50]}... -> {result['summary'][:50]}...")
        
        return {
            "ok": True,
            "executed": not result.get("requires_user_confirmation", False),
            "result": result,
            "plan": plan,
            "confidence": plan.get("confidence", 0.5),
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error in task endpoint: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/memory/stats")
async def get_memory_stats():
    """Get memory statistics"""
    try:
        stats = conversation_memory.get_stats()
        return {"ok": True, "stats": stats, "timestamp": datetime.now().isoformat()}
    except Exception as e:
        logger.error(f"Error getting memory stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/memory/clear")
async def clear_memory():
    """Clear all memory"""
    try:
        conversation_memory.clear()
        logger.info("Memory cleared")
        return {"ok": True, "message": "Memory cleared", "timestamp": datetime.now().isoformat()}
    except Exception as e:
        logger.error(f"Error clearing memory: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/docs")
async def get_docs():
    """Redirect to API documentation"""
    return {"message": "API documentation available at /docs"}

if __name__ == "__main__":
    import uvicorn


